﻿namespace Student_Registration
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.L1 = new System.Windows.Forms.Label();
            this.L2 = new System.Windows.Forms.Label();
            this.T1 = new System.Windows.Forms.TextBox();
            this.L3 = new System.Windows.Forms.Label();
            this.T2 = new System.Windows.Forms.TextBox();
            this.L4 = new System.Windows.Forms.Label();
            this.T3 = new System.Windows.Forms.TextBox();
            this.L5 = new System.Windows.Forms.Label();
            this.T4 = new System.Windows.Forms.TextBox();
            this.L6 = new System.Windows.Forms.Label();
            this.T5 = new System.Windows.Forms.TextBox();
            this.L7 = new System.Windows.Forms.Label();
            this.T6 = new System.Windows.Forms.TextBox();
            this.B1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // L1
            // 
            this.L1.AutoSize = true;
            this.L1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.L1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.23F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L1.Location = new System.Drawing.Point(452, 18);
            this.L1.Name = "L1";
            this.L1.Padding = new System.Windows.Forms.Padding(14);
            this.L1.Size = new System.Drawing.Size(434, 59);
            this.L1.TabIndex = 0;
            this.L1.Text = "Below Are the Saved Credentials ";
            // 
            // L2
            // 
            this.L2.AutoSize = true;
            this.L2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L2.Location = new System.Drawing.Point(201, 142);
            this.L2.Name = "L2";
            this.L2.Padding = new System.Windows.Forms.Padding(11);
            this.L2.Size = new System.Drawing.Size(108, 47);
            this.L2.TabIndex = 1;
            this.L2.Text = "Name : ";
            // 
            // T1
            // 
            this.T1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T1.Location = new System.Drawing.Point(452, 142);
            this.T1.Name = "T1";
            this.T1.Size = new System.Drawing.Size(321, 35);
            this.T1.TabIndex = 2;
            // 
            // L3
            // 
            this.L3.AutoSize = true;
            this.L3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L3.Location = new System.Drawing.Point(201, 234);
            this.L3.Name = "L3";
            this.L3.Padding = new System.Windows.Forms.Padding(11);
            this.L3.Size = new System.Drawing.Size(170, 47);
            this.L3.TabIndex = 3;
            this.L3.Text = "Roll Number : ";
            // 
            // T2
            // 
            this.T2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T2.Location = new System.Drawing.Point(452, 234);
            this.T2.Name = "T2";
            this.T2.Size = new System.Drawing.Size(321, 35);
            this.T2.TabIndex = 4;
            // 
            // L4
            // 
            this.L4.AutoSize = true;
            this.L4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L4.Location = new System.Drawing.Point(201, 333);
            this.L4.Name = "L4";
            this.L4.Padding = new System.Windows.Forms.Padding(11);
            this.L4.Size = new System.Drawing.Size(116, 47);
            this.L4.TabIndex = 5;
            this.L4.Text = "Mobile : ";
            // 
            // T3
            // 
            this.T3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T3.Location = new System.Drawing.Point(452, 333);
            this.T3.Name = "T3";
            this.T3.Size = new System.Drawing.Size(321, 34);
            this.T3.TabIndex = 6;
            // 
            // L5
            // 
            this.L5.AutoSize = true;
            this.L5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L5.Location = new System.Drawing.Point(201, 421);
            this.L5.Name = "L5";
            this.L5.Padding = new System.Windows.Forms.Padding(11);
            this.L5.Size = new System.Drawing.Size(118, 47);
            this.L5.TabIndex = 7;
            this.L5.Text = "Mail ID : ";
            // 
            // T4
            // 
            this.T4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T4.Location = new System.Drawing.Point(452, 421);
            this.T4.Name = "T4";
            this.T4.Size = new System.Drawing.Size(321, 34);
            this.T4.TabIndex = 8;
            // 
            // L6
            // 
            this.L6.AutoSize = true;
            this.L6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L6.Location = new System.Drawing.Point(201, 518);
            this.L6.Name = "L6";
            this.L6.Padding = new System.Windows.Forms.Padding(11);
            this.L6.Size = new System.Drawing.Size(171, 47);
            this.L6.TabIndex = 9;
            this.L6.Text = "Qualification : ";
            // 
            // T5
            // 
            this.T5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T5.Location = new System.Drawing.Point(452, 518);
            this.T5.Name = "T5";
            this.T5.Size = new System.Drawing.Size(321, 34);
            this.T5.TabIndex = 10;
            // 
            // L7
            // 
            this.L7.AutoSize = true;
            this.L7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.L7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L7.Location = new System.Drawing.Point(201, 616);
            this.L7.Name = "L7";
            this.L7.Padding = new System.Windows.Forms.Padding(11);
            this.L7.Size = new System.Drawing.Size(413, 47);
            this.L7.TabIndex = 11;
            this.L7.Text = "Specialization In Highest Qualification : ";
            // 
            // T6
            // 
            this.T6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T6.Location = new System.Drawing.Point(698, 616);
            this.T6.Name = "T6";
            this.T6.Size = new System.Drawing.Size(294, 34);
            this.T6.TabIndex = 12;
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.98F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(509, 698);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(224, 48);
            this.B1.TabIndex = 13;
            this.B1.Text = "Save";
            this.B1.UseVisualStyleBackColor = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1349, 778);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.T6);
            this.Controls.Add(this.L7);
            this.Controls.Add(this.T5);
            this.Controls.Add(this.L6);
            this.Controls.Add(this.T4);
            this.Controls.Add(this.L5);
            this.Controls.Add(this.T3);
            this.Controls.Add(this.L4);
            this.Controls.Add(this.T2);
            this.Controls.Add(this.L3);
            this.Controls.Add(this.T1);
            this.Controls.Add(this.L2);
            this.Controls.Add(this.L1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L1;
        private System.Windows.Forms.Label L2;
        private System.Windows.Forms.TextBox T1;
        private System.Windows.Forms.Label L3;
        private System.Windows.Forms.TextBox T2;
        private System.Windows.Forms.Label L4;
        private System.Windows.Forms.TextBox T3;
        private System.Windows.Forms.Label L5;
        private System.Windows.Forms.TextBox T4;
        private System.Windows.Forms.Label L6;
        private System.Windows.Forms.TextBox T5;
        private System.Windows.Forms.Label L7;
        private System.Windows.Forms.TextBox T6;
        private System.Windows.Forms.Button B1;
    }
}